param(
  [string]$BackendPath = 'D:\vox-social-media\SocialHub_Automation_2K_Phase1_SafePatch\SocialHub-Backend-Threads-AutoPublishing-v1\SocialHub-Backend',
  [string]$PilotPath,
  [switch]$ClientOnly,
  [switch]$Apply
)
$ErrorActionPreference='Stop'
if ([string]::IsNullOrWhiteSpace($PilotPath)) {
  $PilotPath=Join-Path $BackendPath 'SocialHub-Edge-Group-Pilot\SocialHub-Edge-Group-Pilot'
}
$root=$PSScriptRoot
$javaRoot=Join-Path $BackendPath 'src\main\java'
$workerRoot=Join-Path $javaRoot 'com\socialhub\grouppublishingtask\worker'
if (!(Test-Path -LiteralPath (Join-Path $PilotPath 'extension\manifest.json') -PathType Leaf)) {
  throw 'Không tìm thấy extension/manifest.json trong PilotPath; không sửa file.'
}
if (!(Test-Path -LiteralPath $javaRoot -PathType Container)) {
  throw 'Không tìm thấy Backend src/main/java; không sửa file.'
}

# NEVER modify GroupSheetQuickPlanController.java or custom GroupWorkerMediaPreviewController.java.
# Scan for existing Spring endpoints to avoid duplicate request mappings.
function Find-Route([string]$pattern) {
  foreach ($file in (Get-ChildItem -LiteralPath $javaRoot -Filter '*.java' -Recurse -File)) {
    if (Select-String -LiteralPath $file.FullName -Pattern $pattern -Quiet) {
      return $file.FullName
    }
  }
  return $null
}
if (!$ClientOnly) {
  $previewFile=Join-Path $workerRoot 'GroupWorkerMediaPreviewController.java'
  if (!(Test-Path -LiteralPath $previewFile -PathType Leaf)) {
    throw "Media preview Worker đang thiếu: $previewFile; dừng, không tự tạo route khác"
  }
  $previewText=Get-Content -LiteralPath $previewFile -Raw
  if ($previewText -notmatch '@GetMapping\s*\(\s*"/image-manifest"' -or
      $previewText -notmatch '@PostMapping\s*\(\s*"/image-claim"') {
    throw 'Worker tùy chỉnh chưa có image-manifest hoặc image-claim; cần đối chiếu source, không ép ghi đè.'
  }
  Write-Host 'GIỮ NGUYÊN custom GroupWorkerMediaPreviewController.java (có image-manifest và image-claim).' -ForegroundColor Yellow
  $inspectorLocation=Find-Route '@GetMapping\s*\(\s*"/inspect-exact"'
  $videoLocation=Find-Route '@PostMapping\s*\(\s*"/video-claim"'
  if ($inspectorLocation) {
    Write-Host "Đã thấy /inspect-exact trong $inspectorLocation — không tạo route trùng." -ForegroundColor Yellow
  } else {
    Write-Host 'Chưa có /inspect-exact — sẽ thêm Controller READ-ONLY riêng, không sửa Worker custom.' -ForegroundColor Cyan
  }
  if ($videoLocation) {
    Write-Host "Đã thấy /video-claim trong $videoLocation — sẽ giữ nguyên route video hiện tại; chưa chứng minh tương thích LIVE." -ForegroundColor Yellow
  } else {
    Write-Host 'Chưa có /video-claim — sẽ thêm Video Pilot Controller riêng.' -ForegroundColor Cyan
  }
}

$known=@{
  "bridge/bridge.py" = @("8143150FB043165E8344E6DF10CAC36DC8C3BE8F669C4984DEAF3ABFEB333975","81BE34211A7277C1759B046B8B2EFC0F6F0D7FBCD06F6AF3830B37D4A8F2C89C","8C0C625D4B08B5C076C01C1B9D045F8A059B1D6E0662EDEAD373F33F6D6B955F","B86EDA0903E62A4D4DAB5CB76F9AAC3D616F1A37C09104FF0E25AEA3BAA18310")
  "extension/background.js" = @("1DFC6F20E13A6B1EE9DBE70C9777BFC1CD46BA472B8FF4A31C07DCA0A6D66720","2690916B2E42CA64951C7C1A01F0F72576C2802E5C3B63307B25D3F036833BD5","2C88C19D41CD822C36A5CA444B49DD948316734B0635ABDA5468C5C38E6F7678","C8665A61CACC9BBA9AA8CD6CFB17479DE030DDB1D0D5D9AC484F5026D7286C19")
  "extension/content.js" = @("1C6EB5F5991A40B0A8BB7C612E573118763394B555A1F8F84B3CE74EC515242C","294D58D832B4C17CA07A5F0D201F4DFEE0EDE08A047F44784B2A5018A3285566","B87A6CF381E6961EB9B62F82C2CC9D388866B759ED490B1CCF08F9DC9430F4DD","E6ECD8F02F82DB4C54B2EE2961108D331C283B3BDA7A191B7BF9E729DB0B6E1E")
  "extension/popup.js" = @("2632310AF5FE6CE89FCEE9242921F6EEBAA582E90CF58DC05D6884FF4AB5D42B","6B8CF1B3FDE688C47112155D07EA794B7562821369047909B0114ED70AEADFFF","81BECF47E37FEC2847E6B0C74BE46ACC2E3442671C6F00EF4031F476D579F305","9E1AC83F779752863C8011716F83BC44E0304F7517BDB3DB7F0522F1F3AE4698","F2F9825B229D4ABFDE5EA73D70150415CBF3A5DD21B5ED981355D321B1D3D9B0")
  "extension/popup.html" = @("1905C55D111B5196EBE04419D4EA5B1A1A1DC2AE985208F7F82FE0984C994FDF","C8210E0625281535624126F9F029687B6F4E9C5B0BCF4D39A4C7D6A21259222C","DDBB594C54A7AE7834D9C9697F7133228CB3AE7F29A98BD27AEEDB86B256950D")
  "extension/manifest.json" = @("90AA130C33839340CA5F80CFB22666E052267A3BC24570D29F236ADE1A19F365","B667AE3C42DFB7770230F65E4F63B74AC61FBEF37B54B668A3AE02075536ED22","89DC9BBFA53B3AB8460633820241CEB8B66027D0EA077450681F6E575C657FD3")
  "backend/GroupWorkerMediaPreviewController.java" = @("06E29FD88CCA017055DC29CB02B3203C1A6F1D490CB6BCEF9E08380C79BDA85E","FDD65137984FC56C283910FC8F956E5661B4E4C91CFF0C15A476DB92E9134852")
  "backend/GroupWorkerVideoPilotController.java" = @("F1FAC803F09B8FD37258A692014715CAB424024726A6D4CE3C9D3702ECD5CD66")
  "backend/GroupSheetQuickPlanController.java" = @("B3DAAA57B34E4983F11F7BE5EC053613AC62399674B2FD658E1C91F94D9E142E","F74F4219D1ADA7A73313FD73805BECE37EF4C293EEB43E4D00D70DD8ABDA3949")
  "Start-EdgeBridge-Media.ps1" = @("8D0EB323BEEDC757871DA39BE5BD68394923683350A4A9EC9AC6DECA76A2B37E")
}

$destinations=@{
 'bridge/bridge.py' = (Join-Path $PilotPath 'bridge\bridge.py')
 'extension/background.js' = (Join-Path $PilotPath 'extension\background.js')
 'extension/content.js' = (Join-Path $PilotPath 'extension\content.js')
 'extension/popup.js' = (Join-Path $PilotPath 'extension\popup.js')
 'extension/popup.html' = (Join-Path $PilotPath 'extension\popup.html')
 'extension/manifest.json' = (Join-Path $PilotPath 'extension\manifest.json')
 'Start-EdgeBridge-Media.ps1' = (Join-Path $PilotPath 'Start-EdgeBridge-Media.ps1')
}
if (!$ClientOnly) {
  if (!$inspectorLocation) {
    $destinations['backend/GroupWorkerExactInspectionController.java'] = (Join-Path $workerRoot 'GroupWorkerExactInspectionController.java')
  }
  if (!$videoLocation) {
    $destinations['backend/GroupWorkerVideoPilotController.java'] = (Join-Path $workerRoot 'GroupWorkerVideoPilotController.java')
  }
}
$pending=New-Object 'System.Collections.Generic.List[object]'
foreach ($key in @($destinations.Keys | Sort-Object)) {
  $src=Join-Path $root ($key.Replace('/','\'))
  $dst=$destinations[$key]
  if (!(Test-Path -LiteralPath $src -PathType Leaf)) { throw "Gói thiếu file: $key" }
  $srcHash=(Get-FileHash -LiteralPath $src -Algorithm SHA256).Hash
  if (Test-Path -LiteralPath $dst -PathType Leaf) {
    $dstHash=(Get-FileHash -LiteralPath $dst -Algorithm SHA256).Hash
    if ($dstHash -eq $srcHash) {
      Write-Host "Đã đúng phiên bản: $key" -ForegroundColor Green
      continue
    }
    if ($dstHash -notin @($known[$key])) {
      throw "REFUSE overwrite custom file: $dst`nKhông thay file. Gửi bản hiện tại để đối chiếu source thủ công."
    }
  }
  Write-Host "Sẽ cài: $key -> $dst" -ForegroundColor Cyan
  $pending.Add(@{source=$src;target=$dst})
}
Write-Host 'GIỮ NGUYÊN QuickPlan, 1.000 Group Tasks và database; không chạy LIVE.' -ForegroundColor Yellow
if (!$Apply) {
  Write-Host 'DRY-RUN OK: chưa sao chép hoặc sửa bất kỳ file nào.' -ForegroundColor Green
  exit 0
}
$stamp=Get-Date -Format 'yyyyMMdd-HHmmss'
$backups=@()
try {
  foreach ($item in $pending) {
    $dst=$item.target
    New-Item -ItemType Directory -Path (Split-Path $dst -Parent) -Force | Out-Null
    $existed=Test-Path -LiteralPath $dst -PathType Leaf
    $bak=if($existed){"$dst.backup-$stamp"}else{$null}
    if($existed){Copy-Item -LiteralPath $dst -Destination $bak -Force}
    $backups+=@{dst=$dst;bak=$bak}
    Copy-Item -LiteralPath $item.source -Destination $dst -Force
  }
  Write-Host 'MEDIA v13.2 cài xong. KHÔNG khởi động Worker/LIVE; cần build Backend và Reload Extension trước khi inspect.' -ForegroundColor Green
} catch {
  foreach ($item in ($backups | Sort-Object -Descending -Property dst)) {
    if($item.bak -and (Test-Path -LiteralPath $item.bak)) {
      Copy-Item -LiteralPath $item.bak -Destination $item.dst -Force
    } elseif (-not $item.bak) {
      Remove-Item -LiteralPath $item.dst -Force -ErrorAction SilentlyContinue
    }
  }
  throw
}
