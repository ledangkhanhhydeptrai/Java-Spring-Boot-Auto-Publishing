# SocialHub Facebook Group Media v13.2 — Không ghi đè Java tùy chỉnh

## Khác biệt quan trọng so với v13.1

Installer v13.1 liên tiếp dừng vì `GroupSheetQuickPlanController.java` và `GroupWorkerMediaPreviewController.java` có các thay đổi tùy chỉnh. **Không được tiếp tục thêm tên hai file này vào danh sách ghi đè.**

`INSTALL-v13.2.ps1` không bao giờ ghi đè, xóa, sao lưu hoặc thay đổi **hai file Java nói trên**. Bộ lập lịch 1.000 Group Tasks được giữ nguyên. Script không gọi API, không sửa database, không Claim và không đăng Facebook.

V13 so với v12 chỉ bổ sung **`GET /internal/group-worker/inspect-exact`** vào `GroupWorkerMediaPreviewController.java`. Bản v13.2 đưa riêng logic đó vào **`GroupWorkerExactInspectionController.java`**. Trước khi sao chép, installer tìm endpoint `@GetMapping("/inspect-exact")` trên toàn bộ Java source để tránh tạo mapping trùng. Controller này *chỉ đọc* một Task đã cấu hình, kể cả Task đang PENDING.

- Nếu Worker custom đã có `@GetMapping("/image-manifest")` và `@PostMapping("/image-claim")`, giữ nguyên file đó; nếu thiếu thì **từ chối cài đầy đủ**.
- Nếu endpoint inspect đã tồn tại, giữ nguyên. Nếu chưa có, thêm **file Java mới**, không sửa Worker custom.
- Nếu endpoint video `@PostMapping("/video-claim")` đã tồn tại, giữ nguyên; nếu chưa, thêm `GroupWorkerVideoPilotController.java` riêng.
- Với Bridge, Extension và startup script, chỉ thay khi SHA256 khớp bản source quen thuộc. Nếu là custom file không nhận diện được thì dừng, không cưỡng ép ghi đè. Các file thay có backup cùng thư mục.

## Cách chạy (PowerShell Windows)

**Không chạy lại `INSTALL-v13.ps1` cũ.** Giải nén ZIP v13.2 ra Desktop, ví dụ `C:\Users\...\Desktop\SocialHub-Group-Media-v13.2-NoJavaOverwrite`, rồi chạy:

```powershell
$src = "$env:USERPROFILE\Desktop\SocialHub-Group-Media-v13.2-NoJavaOverwrite"

# DRY RUN: chưa sửa bất kỳ file nào
& "$src\INSTALL-v13.2.ps1"

# Chỉ chạy nếu DRY-RUN OK, không có REFUSE
& "$src\INSTALL-v13.2.ps1" -Apply
```

Nếu vẫn có `REFUSE`, dừng và đưa log cùng **file nguồn hiện tại bị từ chối** để merge đúng phần thay đổi. Tuyệt đối không xóa file, sửa hash hoặc dùng `-Force` ngoài script.

Sau cài thành công: build Backend (chưa thể xác nhận bằng unit test trên project thật), chọn thời điểm restart an toàn đối với Fanpage/Threads; mở `chrome://extensions` và Reload đúng extension đang nạp từ thư mục Pilot. Nếu vẫn thấy 0.2.1, extension Chrome đang lấy source từ đường dẫn khác; có thể tắt bản cũ rồi Load unpacked từ thư mục `$pilot\extension`.

## Test chỉ đọc trên UI/extension

- Giữ nguyên Task ảnh #033 `92edb707-50de-4664-884e-3c419e61c3df` ở PENDING.
- Video #044 `43684c23-d16a-4db5-81da-480d375fb6b0` đang READY, chưa có lịch trong UI: **giữ Group Worker dừng**, chưa bấm Claim/LIVE.
- Kiểm tra popup extension phiên bản **0.3.2**. Test nút **0. Kiểm tra ảnh/video/lịch PENDING** sau khi Backend và Bridge dùng cùng exact Task ID và Group ID.
- Đăng ảnh, MP4/Reel LIVE chỉ khi đã xác thực được upload và hoàn tất Facebook Composer với đúng nội dung/media. Nếu không rõ trạng thái, chuyển NEEDS_REVIEW và không tự retry.

Giới hạn: v13.2 chưa được build trong source Backend thực tế trên máy người dùng; chưa xác nhận upload media trên Facebook thật; không đảm bảo Facebook hiển thị video Group dưới dạng Reel. Bản này chưa mở Group Worker tự động cho 999 Task PENDING.

## Chỉ cập nhật Client (khi Backend cần merge thủ công)

```powershell
& "$src\INSTALL-v13.2.ps1" -ClientOnly
& "$src\INSTALL-v13.2.ps1" -ClientOnly -Apply
```

Lựa chọn này chỉ cài Bridge, Extension và startup script. **Không chứng minh Backend đã sẵn sàng cho media** và không được dùng để Claim/đăng LIVE khi chưa kiểm tra đủ các endpoint.
