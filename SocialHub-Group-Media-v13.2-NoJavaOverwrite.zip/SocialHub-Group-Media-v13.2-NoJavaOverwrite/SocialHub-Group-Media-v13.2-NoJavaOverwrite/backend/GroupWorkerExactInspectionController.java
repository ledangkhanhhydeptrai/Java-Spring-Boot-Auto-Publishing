package com.socialhub.grouppublishingtask.worker;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.UUID;

/**
 * Read-only, exactly one authorized Group Task inspection for the media pilot.
 * Separate class so custom GroupWorkerMediaPreviewController is NEVER overwritten.
 * This endpoint does not approve, claim, schedule or publish anything.
 */
@RestController
@RequestMapping("/internal/group-worker")
public class GroupWorkerExactInspectionController {
    private final JdbcTemplate db;

    public GroupWorkerExactInspectionController(JdbcTemplate db) {
        this.db = db;
    }

    @Value("${app.group-worker-token:${GROUP_WORKER_TOKEN:}}")
    private String workerToken;

    @Value("${GROUP_WORKER_TARGET_TASK_ID:}")
    private String targetTaskId;

    @Value("${GROUP_WORKER_EXPECTED_GROUP_ID:}")
    private String expectedGroupId;

    public record Inspection(
            UUID id, String groupUrl, String content,
            String taskStatus, String postStatus, String approvalStatus,
            boolean due, int imageCount, int unsupportedMediaCount) {}

    private void authenticate(String authorization) {
        String token = workerToken == null ? "" : workerToken;
        if (token.isBlank() || authorization == null ||
                !MessageDigest.isEqual(
                        ("Bearer " + token).getBytes(StandardCharsets.UTF_8),
                        authorization.getBytes(StandardCharsets.UTF_8))) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED);
        }
    }

    @GetMapping("/inspect-exact")
    public ResponseEntity<Inspection> inspect(
            @RequestHeader(value = "Authorization", required = false) String authorization) {
        authenticate(authorization);
        if (expectedGroupId == null || !expectedGroupId.matches("[0-9]+")) {
            return ResponseEntity.noContent().build();
        }
        final UUID exactId;
        try {
            exactId = UUID.fromString(targetTaskId == null ? "" : targetTaskId.trim());
        } catch (RuntimeException ignored) {
            return ResponseEntity.noContent().build();
        }
        var rows = db.query("""
                SELECT t.id, g.group_url, p.content, t.status AS task_status,
                       p.status AS post_status, p.approval_status,
                       (COALESCE(t.scheduled_at, t.created_at) <= NOW()) AS due,
                       (SELECT COUNT(*) FROM post_media pm WHERE pm.post_id = t.post_id
                            AND pm.media_type = 'IMAGE') AS image_count,
                       (SELECT COUNT(*) FROM post_media pm WHERE pm.post_id = t.post_id
                            AND pm.media_type IS DISTINCT FROM 'IMAGE') AS unsupported_count
                FROM group_publishing_tasks t
                JOIN posts p ON p.id = t.post_id
                JOIN facebook_groups g ON g.id = t.facebook_group_id
                WHERE t.id = ? AND g.external_group_id = ?
                      AND p.workspace_id = g.workspace_id
                """, (rs, rowNum) -> new Inspection(
                rs.getObject("id", UUID.class),
                rs.getString("group_url"),
                rs.getString("content"),
                rs.getString("task_status"),
                rs.getString("post_status"),
                rs.getString("approval_status"),
                rs.getBoolean("due"),
                rs.getInt("image_count"),
                rs.getInt("unsupported_count")
        ), exactId, expectedGroupId);
        if (rows.size() != 1) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(rows.get(0));
    }
}
